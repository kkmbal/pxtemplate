package portalxpert.person.person300.vo;

public class PsnTmlnInfoVO {	
	private int tmlnSeq;
	private int upTmlnSeq;
	private String objrDiv;
	private String userId;
	private String userNick;
	private String userName;
	private String tmlnDiv;
	private String tmlnKind;
	private String tmlnTitle;
	private String tmlnConts;
	private String tmlnSrc;
	private String relaUrl;
	private int opnCnt;
	private int agrmCnt;
	private int oppCnt;
	private int likeCnt;
	private String delYn;
	private String regrId;
	private String regrName;
	private String regDttm;
	private String updrId;
	private String updrName;
	private String updDttm;
	private int evalCnt;
	private int rowNum;
	private String viewMode;
	private String faceImg;
	private String readYn;
	private String objrId;
	
	public int getTmlnSeq() {
		return tmlnSeq;
	}
	public void setTmlnSeq(int tmlnSeq) {
		this.tmlnSeq = tmlnSeq;
	}
	public int getUpTmlnSeq() {
		return upTmlnSeq;
	}
	public void setUpTmlnSeq(int upTmlnSeq) {
		this.upTmlnSeq = upTmlnSeq;
	}
	public String getObjrDiv() {
		return objrDiv;
	}
	public void setObjrDiv(String objrDiv) {
		this.objrDiv = objrDiv;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserNick() {
		return userNick;
	}
	public void setUserNick(String userNick) {
		this.userNick = userNick;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getTmlnDiv() {
		return tmlnDiv;
	}
	public void setTmlnDiv(String tmlnDiv) {
		this.tmlnDiv = tmlnDiv;
	}
	public String getTmlnKind() {
		return tmlnKind;
	}
	public void setTmlnKind(String tmlnKind) {
		this.tmlnKind = tmlnKind;
	}
	public String getTmlnTitle() {
		return tmlnTitle;
	}
	public void setTmlnTitle(String tmlnTitle) {
		this.tmlnTitle = tmlnTitle;
	}
	public String getTmlnConts() {
		return tmlnConts;
	}
	public void setTmlnConts(String tmlnConts) {
		this.tmlnConts = tmlnConts;
	}
	public String getTmlnSrc() {
		return tmlnSrc;
	}
	public void setTmlnSrc(String tmlnSrc) {
		this.tmlnSrc = tmlnSrc;
	}
	public String getRelaUrl() {
		return relaUrl;
	}
	public void setRelaUrl(String relaUrl) {
		this.relaUrl = relaUrl;
	}
	public int getOpnCnt() {
		return opnCnt;
	}
	public void setOpnCnt(int opnCnt) {
		this.opnCnt = opnCnt;
	}
	public int getAgrmCnt() {
		return agrmCnt;
	}
	public void setAgrmCnt(int agrmCnt) {
		this.agrmCnt = agrmCnt;
	}
	public int getOppCnt() {
		return oppCnt;
	}
	public void setOppCnt(int oppCnt) {
		this.oppCnt = oppCnt;
	}
	public int getLikeCnt() {
		return likeCnt;
	}
	public void setLikeCnt(int likeCnt) {
		this.likeCnt = likeCnt;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getRegrId() {
		return regrId;
	}
	public void setRegrId(String regrId) {
		this.regrId = regrId;
	}
	public String getRegrName() {
		return regrName;
	}
	public void setRegrName(String regrName) {
		this.regrName = regrName;
	}
	public String getRegDttm() {
		return regDttm;
	}
	public void setRegDttm(String regDttm) {
		this.regDttm = regDttm;
	}
	public String getUpdrId() {
		return updrId;
	}
	public void setUpdrId(String updrId) {
		this.updrId = updrId;
	}
	public String getUpdrName() {
		return updrName;
	}
	public void setUpdrName(String updrName) {
		this.updrName = updrName;
	}
	public String getUpdDttm() {
		return updDttm;
	}
	public void setUpdDttm(String updDttm) {
		this.updDttm = updDttm;
	}
	public int getEvalCnt() {
		return evalCnt;
	}
	public void setEvalCnt(int evalCnt) {
		this.evalCnt = evalCnt;
	}
	public int getRowNum() {
		return rowNum;
	}
	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}
	public String getViewMode() {
		return viewMode;
	}
	public void setViewMode(String viewMode) {
		this.viewMode = viewMode;
	}
	public String getFaceImg() {
		return faceImg;
	}
	public void setFaceImg(String faceImg) {
		this.faceImg = faceImg;
	}
	public String getReadYn() {
		return readYn;
	}
	public void setReadYn(String readYn) {
		this.readYn = readYn;
	}
	public String getObjrId() {
		return objrId;
	}
	public void setObjrId(String objrId) {
		this.objrId = objrId;
	}
	
	

}
