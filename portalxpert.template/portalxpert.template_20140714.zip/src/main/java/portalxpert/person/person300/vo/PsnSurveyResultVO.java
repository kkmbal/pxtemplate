package portalxpert.person.person300.vo;

public class PsnSurveyResultVO {	
	private int tmlnSeq;	 
	private int totCnt;
	private String beginDttm;
	private String endDttm;
	private String notiId;
	public String getNotiId() {
		return notiId;
	}
	public void setNotiId(String notiId) {
		this.notiId = notiId;
	}
	public int getTmlnSeq() {
		return tmlnSeq;
	}
	public void setTmlnSeq(int tmlnSeq) {
		this.tmlnSeq = tmlnSeq;
	}
	public int getTotCnt() {
		return totCnt;
	}
	public void setTotCnt(int totCnt) {
		this.totCnt = totCnt;
	}
	public String getBeginDttm() {
		return beginDttm;
	}
	public void setBeginDttm(String beginDttm) {
		this.beginDttm = beginDttm;
	}
	public String getEndDttm() {
		return endDttm;
	}
	public void setEndDttm(String endDttm) {
		this.endDttm = endDttm;
	}
	
	
	

}
