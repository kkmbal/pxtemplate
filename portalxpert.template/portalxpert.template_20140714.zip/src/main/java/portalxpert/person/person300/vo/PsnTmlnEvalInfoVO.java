package portalxpert.person.person300.vo;

public class PsnTmlnEvalInfoVO {
	
	private int tmlnSeq;
	private String tmlnEvalDiv;
	private String userId;
	private int evalSeq;
	private String userName;
	private String evalDttm;
	private String delYn;
	private String regrId;
	private String regrName;
	private String regDttm;
	private String updrId;
	private String updrName;
	private String updDttm;
	private String userNick;
	private int evalCnt;
	private String viewMode;
	private String ou;
	
	private int rowNum;	
	public int getTmlnSeq() {
		return tmlnSeq;
	}
	public void setTmlnSeq(int tmlnSeq) {
		this.tmlnSeq = tmlnSeq;
	}
	public String getTmlnEvalDiv() {
		return tmlnEvalDiv;
	}
	public void setTmlnEvalDiv(String tmlnEvalDiv) {
		this.tmlnEvalDiv = tmlnEvalDiv;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getEvalSeq() {
		return evalSeq;
	}
	public void setEvalSeq(int evalSeq) {
		this.evalSeq = evalSeq;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEvalDttm() {
		return evalDttm;
	}
	public void setEvalDttm(String evalDttm) {
		this.evalDttm = evalDttm;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getRegrId() {
		return regrId;
	}
	public void setRegrId(String regrId) {
		this.regrId = regrId;
	}
	public String getRegrName() {
		return regrName;
	}
	public void setRegrName(String regrName) {
		this.regrName = regrName;
	}
	public String getRegDttm() {
		return regDttm;
	}
	public void setRegDttm(String regDttm) {
		this.regDttm = regDttm;
	}
	public String getUpdrId() {
		return updrId;
	}
	public void setUpdrId(String updrId) {
		this.updrId = updrId;
	}
	public String getUpdrName() {
		return updrName;
	}
	public void setUpdrName(String updrName) {
		this.updrName = updrName;
	}
	public String getUpdDttm() {
		return updDttm;
	}
	public void setUpdDttm(String updDttm) {
		this.updDttm = updDttm;
	}
	public String getUserNick() {
		return userNick;
	}
	public void setUserNick(String userNick) {
		this.userNick = userNick;
	}
	public int getEvalCnt() {
		return evalCnt;
	}
	public void setEvalCnt(int evalCnt) {
		this.evalCnt = evalCnt;
	}
	public String getViewMode() {
		return viewMode;
	}
	public void setViewMode(String viewMode) {
		this.viewMode = viewMode;
	}
	public int getRowNum() {
		return rowNum;
	}
	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}
	public String getOu() {
		return ou;
	}
	public void setOu(String ou) {
		this.ou = ou;
	}
    

}
