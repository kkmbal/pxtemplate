package portalxpert.person.person300.vo;

public class PsnTmlnOpnVO {
	private int tmlnSeq;
	private int tmlnOpnSeq;
	private int upOpnSeq;
	private String userId;
	private String userName;
	private String userNick;
	private String opnConts;
	private String delYn;
	private String regrId;
	private String regrName;
	private String regDttm;
	private String updrId;
	private String updrName;
	private String updDttm;
	private String tmlnDiv;
	private String viewMode;
	private String faceImg;
	private int rowNum;
	private String readYn;
	public int getTmlnSeq() {
		return tmlnSeq;
	}
	public void setTmlnSeq(int tmlnSeq) {
		this.tmlnSeq = tmlnSeq;
	}
	public int getTmlnOpnSeq() {
		return tmlnOpnSeq;
	}
	public void setTmlnOpnSeq(int tmlnOpnSeq) {
		this.tmlnOpnSeq = tmlnOpnSeq;
	}
	public int getUpOpnSeq() {
		return upOpnSeq;
	}
	public void setUpOpnSeq(int upOpnSeq) {
		this.upOpnSeq = upOpnSeq;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserNick() {
		return userNick;
	}
	public void setUserNick(String userNick) {
		this.userNick = userNick;
	}
	public String getOpnConts() {
		return opnConts;
	}
	public void setOpnConts(String opnConts) {
		this.opnConts = opnConts;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getRegrId() {
		return regrId;
	}
	public void setRegrId(String regrId) {
		this.regrId = regrId;
	}
	public String getRegrName() {
		return regrName;
	}
	public void setRegrName(String regrName) {
		this.regrName = regrName;
	}
	public String getRegDttm() {
		return regDttm;
	}
	public void setRegDttm(String regDttm) {
		this.regDttm = regDttm;
	}
	public String getUpdrId() {
		return updrId;
	}
	public void setUpdrId(String updrId) {
		this.updrId = updrId;
	}
	public String getUpdrName() {
		return updrName;
	}
	public void setUpdrName(String updrName) {
		this.updrName = updrName;
	}
	public String getUpdDttm() {
		return updDttm;
	}
	public void setUpdDttm(String updDttm) {
		this.updDttm = updDttm;
	}
	public String getTmlnDiv() {
		return tmlnDiv;
	}
	public void setTmlnDiv(String tmlnDiv) {
		this.tmlnDiv = tmlnDiv;
	}
	public String getViewMode() {
		return viewMode;
	}
	public void setViewMode(String viewMode) {
		this.viewMode = viewMode;
	}
	public int getRowNum() {
		return rowNum;
	}
	public void setRowNum(int rowNum) {
		this.rowNum = rowNum;
	}
	public String getFaceImg() {
		return faceImg;
	}
	public void setFaceImg(String faceImg) {
		this.faceImg = faceImg;
	}
	public String getReadYn() {
		return readYn;
	}
	public void setReadYn(String readYn) {
		this.readYn = readYn;
	}
	
	

}
