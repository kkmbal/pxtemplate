package portalxpert.person.person200.vo;

public class MyMemberVO {
	
	private String displayname;
	
	private String titlename;
	private String ou;
	
	
	
	public String getDisplayname() {
		return displayname;
	}
	public void setDisplayname(String displayname) {
		this.displayname = displayname;
	}
	public String getTitlename() {
		return titlename;
	}
	public void setTitlename(String titlename) {
		this.titlename = titlename;
	}
	public String getOu() {
		return ou;
	}
	public void setOu(String ou) {
		this.ou = ou;
	}

	
	
	
	
}
