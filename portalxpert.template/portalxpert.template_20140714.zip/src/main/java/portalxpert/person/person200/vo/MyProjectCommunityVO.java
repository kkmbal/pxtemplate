package portalxpert.person.person200.vo;

public class MyProjectCommunityVO {
	
	
	private String catgId; /**/                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     
	private String commName; /**/   
	private String clerkNo; /**/ 
	private String linkUrl; /**/
	private String mGubun; /**/
	private String userId;
	private String nameLen;
	private String ssno;
	
	
	
	public String getNameLen() {
		return nameLen;
	}
	public void setNameLen(String nameLen) {
		this.nameLen = nameLen;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getmGubun() {
		return mGubun;
	}
	public void setmGubun(String mGubun) {
		this.mGubun = mGubun;
	}
	public String getCatgId() {
		return catgId;
	}
	public void setCatgId(String catgId) {
		this.catgId = catgId;
	}
	public String getCommName() {
		return commName;
	}
	public void setCommName(String commName) {
		this.commName = commName;
	}
	public String getClerkNo() {
		return clerkNo;
	}
	public void setClerkNo(String clerkNo) {
		this.clerkNo = clerkNo;
	}
	public String getLinkUrl() {
		return linkUrl;
	}
	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}
	public String getSsno() {
		return ssno;
	}
	public void setSsno(String ssno) {
		this.ssno = ssno;
	}   
	
}
