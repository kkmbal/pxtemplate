package portalxpert.person.person100.vo;

public class PbsUserNotiInfoVO {
	
	private int notiSeq;
	private String upNotiSeq;
	private String emgcYn;
	private String anmtYn;
	private String notiTitle;
	private String titleBoldYn;
	private String titleColorDiv;
	private String notiConts;
	private String linkUrl;
	private String notiTp;
	private String notiKind;
	private String nickUseYn;
	private String userNick;
	private String userName;
	private String editDiv;
	private String rsrvYn;
	private String notiBgnDttm;
	private String notiEndDttm;
	private String notiOpenDiv;
	private String notiOpenDivSpec;
	private String publAsgnDiv;
	private String publAsgnDivSpec;
	private String replyPrmsYn;
	private String replyMakrRealnameYn;
	private String opnPrmsYn;
	private String opnMakrRealnameYn;
	private int notiReadCnt;
	private int notiOpnCnt;
	private int notiAgrmCnt;
	private int notiOppCnt;
	private int notiLikeCnt;
	private String statCode;
	private String deptCode;
	private String deptName;
	private String deptFname;
	private String makrIp;
	private String delYn;
	private String regrId;
	private String regrName;
	private String regDttm;
	private String updrId;
	private String updrName;
	private String updDttm;
	private String boardId;
	
	public int getNotiSeq() {
		return notiSeq;
	}
	public void setNotiSeq(int notiSeq) {
		this.notiSeq = notiSeq;
	}
	public String getUpNotiSeq() {
		return upNotiSeq;
	}
	public void setUpNotiSeq(String upNotiSeq) {
		this.upNotiSeq = upNotiSeq;
	}
	public String getEmgcYn() {
		return emgcYn;
	}
	public void setEmgcYn(String emgcYn) {
		this.emgcYn = emgcYn;
	}
	public String getAnmtYn() {
		return anmtYn;
	}
	public void setAnmtYn(String anmtYn) {
		this.anmtYn = anmtYn;
	}
	public String getNotiTitle() {
		return notiTitle;
	}
	public void setNotiTitle(String notiTitle) {
		this.notiTitle = notiTitle;
	}
	public String getTitleBoldYn() {
		return titleBoldYn;
	}
	public void setTitleBoldYn(String titleBoldYn) {
		this.titleBoldYn = titleBoldYn;
	}
	public String getTitleColorDiv() {
		return titleColorDiv;
	}
	public void setTitleColorDiv(String titleColorDiv) {
		this.titleColorDiv = titleColorDiv;
	}
	public String getNotiConts() {
		return notiConts;
	}
	public void setNotiConts(String notiConts) {
		this.notiConts = notiConts;
	}
	public String getLinkUrl() {
		return linkUrl;
	}
	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}
	public String getNotiTp() {
		return notiTp;
	}
	public void setNotiTp(String notiTp) {
		this.notiTp = notiTp;
	}
	public String getNotiKind() {
		return notiKind;
	}
	public void setNotiKind(String notiKind) {
		this.notiKind = notiKind;
	}
	public String getNickUseYn() {
		return nickUseYn;
	}
	public void setNickUseYn(String nickUseYn) {
		this.nickUseYn = nickUseYn;
	}
	public String getUserNick() {
		return userNick;
	}
	public void setUserNick(String userNick) {
		this.userNick = userNick;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEditDiv() {
		return editDiv;
	}
	public void setEditDiv(String editDiv) {
		this.editDiv = editDiv;
	}
	public String getRsrvYn() {
		return rsrvYn;
	}
	public void setRsrvYn(String rsrvYn) {
		this.rsrvYn = rsrvYn;
	}
	public String getNotiBgnDttm() {
		return notiBgnDttm;
	}
	public void setNotiBgnDttm(String notiBgnDttm) {
		this.notiBgnDttm = notiBgnDttm;
	}
	public String getNotiEndDttm() {
		return notiEndDttm;
	}
	public void setNotiEndDttm(String notiEndDttm) {
		this.notiEndDttm = notiEndDttm;
	}
	public String getNotiOpenDiv() {
		return notiOpenDiv;
	}
	public void setNotiOpenDiv(String notiOpenDiv) {
		this.notiOpenDiv = notiOpenDiv;
	}
	public String getNotiOpenDivSpec() {
		return notiOpenDivSpec;
	}
	public void setNotiOpenDivSpec(String notiOpenDivSpec) {
		this.notiOpenDivSpec = notiOpenDivSpec;
	}
	public String getPublAsgnDiv() {
		return publAsgnDiv;
	}
	public void setPublAsgnDiv(String publAsgnDiv) {
		this.publAsgnDiv = publAsgnDiv;
	}
	public String getPublAsgnDivSpec() {
		return publAsgnDivSpec;
	}
	public void setPublAsgnDivSpec(String publAsgnDivSpec) {
		this.publAsgnDivSpec = publAsgnDivSpec;
	}
	public String getReplyPrmsYn() {
		return replyPrmsYn;
	}
	public void setReplyPrmsYn(String replyPrmsYn) {
		this.replyPrmsYn = replyPrmsYn;
	}
	public String getReplyMakrRealnameYn() {
		return replyMakrRealnameYn;
	}
	public void setReplyMakrRealnameYn(String replyMakrRealnameYn) {
		this.replyMakrRealnameYn = replyMakrRealnameYn;
	}
	public String getOpnPrmsYn() {
		return opnPrmsYn;
	}
	public void setOpnPrmsYn(String opnPrmsYn) {
		this.opnPrmsYn = opnPrmsYn;
	}
	public String getOpnMakrRealnameYn() {
		return opnMakrRealnameYn;
	}
	public void setOpnMakrRealnameYn(String opnMakrRealnameYn) {
		this.opnMakrRealnameYn = opnMakrRealnameYn;
	}
	public int getNotiReadCnt() {
		return notiReadCnt;
	}
	public void setNotiReadCnt(int notiReadCnt) {
		this.notiReadCnt = notiReadCnt;
	}
	public int getNotiOpnCnt() {
		return notiOpnCnt;
	}
	public void setNotiOpnCnt(int notiOpnCnt) {
		this.notiOpnCnt = notiOpnCnt;
	}
	public int getNotiAgrmCnt() {
		return notiAgrmCnt;
	}
	public void setNotiAgrmCnt(int notiAgrmCnt) {
		this.notiAgrmCnt = notiAgrmCnt;
	}
	public int getNotiOppCnt() {
		return notiOppCnt;
	}
	public void setNotiOppCnt(int notiOppCnt) {
		this.notiOppCnt = notiOppCnt;
	}
	public int getNotiLikeCnt() {
		return notiLikeCnt;
	}
	public void setNotiLikeCnt(int notiLikeCnt) {
		this.notiLikeCnt = notiLikeCnt;
	}
	public String getStatCode() {
		return statCode;
	}
	public void setStatCode(String statCode) {
		this.statCode = statCode;
	}
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDeptFname() {
		return deptFname;
	}
	public void setDeptFname(String deptFname) {
		this.deptFname = deptFname;
	}
	public String getMakrIp() {
		return makrIp;
	}
	public void setMakrIp(String makrIp) {
		this.makrIp = makrIp;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getRegrId() {
		return regrId;
	}
	public void setRegrId(String regrId) {
		this.regrId = regrId;
	}
	public String getRegrName() {
		return regrName;
	}
	public void setRegrName(String regrName) {
		this.regrName = regrName;
	}
	public String getRegDttm() {
		return regDttm;
	}
	public void setRegDttm(String regDttm) {
		this.regDttm = regDttm;
	}
	public String getUpdrId() {
		return updrId;
	}
	public void setUpdrId(String updrId) {
		this.updrId = updrId;
	}
	public String getUpdrName() {
		return updrName;
	}
	public void setUpdrName(String updrName) {
		this.updrName = updrName;
	}
	public String getUpdDttm() {
		return updDttm;
	}
	public void setUpdDttm(String updDttm) {
		this.updDttm = updDttm;
	}
	public String getBoardId() {
		return boardId;
	}
	public void setBoardId(String boardId) {
		this.boardId = boardId;
	}
	

}
