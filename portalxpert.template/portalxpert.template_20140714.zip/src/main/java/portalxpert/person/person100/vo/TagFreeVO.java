package portalxpert.person.person100.vo;

public class TagFreeVO {
	
	private String mineBody; /**/    
	//private String temp_body; /**/    
	private String editMethod; /**/
	private String bodyHtmlSrc;
	private String notiConts;
	private String notiId;
	
	public String getNotiId() {
		return notiId;
	}
	public void setNotiId(String notiId) {
		this.notiId = notiId;
	}
	public String getNotiConts() {
		return notiConts;
	}
	public void setNotiConts(String notiConts) {
		this.notiConts = notiConts;
	}
	public String getBodyHtmlSrc() {
		return bodyHtmlSrc;
	}
	public void setBodyHtmlSrc(String bodyHtmlSrc) {
		this.bodyHtmlSrc = bodyHtmlSrc;
	}
	
	public String getMineBody() {
		return mineBody;
	}
	public void setMineBody(String mineBody) {
		this.mineBody = mineBody;
	}
	/*
	public String getTemp_body() {
		return temp_body;
	}
	public void setTemp_body(String temp_body) {
		this.temp_body = temp_body;
	}
	*/
	public String getEditMethod() {
		return editMethod;
	}
	public void setEditMethod(String editMethod) {
		this.editMethod = editMethod;
	}    
	

}
