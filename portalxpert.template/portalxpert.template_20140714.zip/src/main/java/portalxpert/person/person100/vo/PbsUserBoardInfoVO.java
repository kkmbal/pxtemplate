package portalxpert.person.person100.vo;

public class PbsUserBoardInfoVO {
	
	private String boardId;
	private String boardTp;
	private String boardOwnrId;
	private String boardOwnrName;
	private String boardName;
	private String boardExpl;
	private String apndFileUseYn;
	private String apndFileCnt;
	private String apndFileSz;
	private String delYn;
	private String regrId;
	private String regrName;
	private String regDttm;
	private String updrId;
	private String updrName;
	private String updDttm;
	private String cont;
	
	public String getCont() {
		return cont;
	}
	public void setCont(String cont) {
		this.cont = cont;
	}
	public String getBoardId() {
		return boardId;
	}
	public void setBoardId(String boardId) {
		this.boardId = boardId;
	}
	public String getBoardTp() {
		return boardTp;
	}
	public void setBoardTp(String boardTp) {
		this.boardTp = boardTp;
	}
	public String getBoardOwnrId() {
		return boardOwnrId;
	}
	public void setBoardOwnrId(String boardOwnrId) {
		this.boardOwnrId = boardOwnrId;
	}
	public String getBoardOwnrName() {
		return boardOwnrName;
	}
	public void setBoardOwnrName(String boardOwnrName) {
		this.boardOwnrName = boardOwnrName;
	}
	public String getBoardName() {
		return boardName;
	}
	public void setBoardName(String boardName) {
		this.boardName = boardName;
	}
	public String getBoardExpl() {
		return boardExpl;
	}
	public void setBoardExpl(String boardExpl) {
		this.boardExpl = boardExpl;
	}
	public String getApndFileUseYn() {
		return apndFileUseYn;
	}
	public void setApndFileUseYn(String apndFileUseYn) {
		this.apndFileUseYn = apndFileUseYn;
	}
	public String getApndFileCnt() {
		return apndFileCnt;
	}
	public void setApndFileCnt(String apndFileCnt) {
		this.apndFileCnt = apndFileCnt;
	}
	public String getApndFileSz() {
		return apndFileSz;
	}
	public void setApndFileSz(String apndFileSz) {
		this.apndFileSz = apndFileSz;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getRegrId() {
		return regrId;
	}
	public void setRegrId(String regrId) {
		this.regrId = regrId;
	}
	public String getRegrName() {
		return regrName;
	}
	public void setRegrName(String regrName) {
		this.regrName = regrName;
	}
	public String getRegDttm() {
		return regDttm;
	}
	public void setRegDttm(String regDttm) {
		this.regDttm = regDttm;
	}
	public String getUpdrId() {
		return updrId;
	}
	public void setUpdrId(String updrId) {
		this.updrId = updrId;
	}
	public String getUpdrName() {
		return updrName;
	}
	public void setUpdrName(String updrName) {
		this.updrName = updrName;
	}
	public String getUpdDttm() {
		return updDttm;
	}
	public void setUpdDttm(String updDttm) {
		this.updDttm = updDttm;
	}
	

}
