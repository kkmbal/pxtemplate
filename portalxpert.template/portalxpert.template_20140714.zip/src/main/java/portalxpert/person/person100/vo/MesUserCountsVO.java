package portalxpert.person.person100.vo;

public class MesUserCountsVO {
	
	private String sid;
	private int rmr;
	private int eap;
	private String eapTime;
	private int ang;
	private int mro;
	private String mroTime;
	private int awf;
	private int uwf;
	private int swf;
	private int rwf;
	private String kms;
	private String kmsTime;
	private int acr;
	private String acrTime;
	private int dsc;
	private String dscTime;
	private int ddb;
	private String ddbTime;
	private int ehc;
	private String ehcTime;
	private int p01;
	private int p02;
	private int p03;
	private int pdc;
	private String p01Time;
	private String p02Time;
	private String p03Time;
	private String pdcTime;
	private int csc;
	private String cscTime;
	private int smc;
	private String smcTime;
	private String sidTmp;
	private String sidTmp1;
	private String resiNumber;
	
	public String getResiNumber() {
		return resiNumber;
	}
	public void setResiNumber(String resiNumber) {
		this.resiNumber = resiNumber;
	}
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
	public int getRmr() {
		return rmr;
	}
	public void setRmr(int rmr) {
		this.rmr = rmr;
	}
	public int getEap() {
		return eap;
	}
	public void setEap(int eap) {
		this.eap = eap;
	}
	public String getEapTime() {
		return eapTime;
	}
	public void setEapTime(String eapTime) {
		this.eapTime = eapTime;
	}
	public int getAng() {
		return ang;
	}
	public void setAng(int ang) {
		this.ang = ang;
	}
	public int getMro() {
		return mro;
	}
	public void setMro(int mro) {
		this.mro = mro;
	}
	public String getMroTime() {
		return mroTime;
	}
	public void setMroTime(String mroTime) {
		this.mroTime = mroTime;
	}
	public int getAwf() {
		return awf;
	}
	public void setAwf(int awf) {
		this.awf = awf;
	}
	public int getUwf() {
		return uwf;
	}
	public void setUwf(int uwf) {
		this.uwf = uwf;
	}
	public int getSwf() {
		return swf;
	}
	public void setSwf(int swf) {
		this.swf = swf;
	}
	public int getRwf() {
		return rwf;
	}
	public void setRwf(int rwf) {
		this.rwf = rwf;
	}
	public String getKms() {
		return kms;
	}
	public void setKms(String kms) {
		this.kms = kms;
	}
	public String getKmsTime() {
		return kmsTime;
	}
	public void setKmsTime(String kmsTime) {
		this.kmsTime = kmsTime;
	}
	public int getAcr() {
		return acr;
	}
	public void setAcr(int acr) {
		this.acr = acr;
	}
	public String getAcrTime() {
		return acrTime;
	}
	public void setAcrTime(String acrTime) {
		this.acrTime = acrTime;
	}
	public int getDsc() {
		return dsc;
	}
	public void setDsc(int dsc) {
		this.dsc = dsc;
	}
	public String getDscTime() {
		return dscTime;
	}
	public void setDscTime(String dscTime) {
		this.dscTime = dscTime;
	}
	public int getDdb() {
		return ddb;
	}
	public void setDdb(int ddb) {
		this.ddb = ddb;
	}
	public String getDdbTime() {
		return ddbTime;
	}
	public void setDdbTime(String ddbTime) {
		this.ddbTime = ddbTime;
	}
	public int getEhc() {
		return ehc;
	}
	public void setEhc(int ehc) {
		this.ehc = ehc;
	}
	public String getEhcTime() {
		return ehcTime;
	}
	public void setEhcTime(String ehcTime) {
		this.ehcTime = ehcTime;
	}
	public int getP01() {
		return p01;
	}
	public void setP01(int p01) {
		this.p01 = p01;
	}
	public int getP02() {
		return p02;
	}
	public void setP02(int p02) {
		this.p02 = p02;
	}
	public int getP03() {
		return p03;
	}
	public void setP03(int p03) {
		this.p03 = p03;
	}
	public int getPdc() {
		return pdc;
	}
	public void setPdc(int pdc) {
		this.pdc = pdc;
	}
	public String getP01Time() {
		return p01Time;
	}
	public void setP01Time(String p01Time) {
		this.p01Time = p01Time;
	}
	public String getP02Time() {
		return p02Time;
	}
	public void setP02Time(String p02Time) {
		this.p02Time = p02Time;
	}
	public String getP03Time() {
		return p03Time;
	}
	public void setP03Time(String p03Time) {
		this.p03Time = p03Time;
	}
	public String getPdcTime() {
		return pdcTime;
	}
	public void setPdcTime(String pdcTime) {
		this.pdcTime = pdcTime;
	}
	public int getCsc() {
		return csc;
	}
	public void setCsc(int csc) {
		this.csc = csc;
	}
	public String getCscTime() {
		return cscTime;
	}
	public void setCscTime(String cscTime) {
		this.cscTime = cscTime;
	}
	public int getSmc() {
		return smc;
	}
	public void setSmc(int smc) {
		this.smc = smc;
	}
	public String getSmcTime() {
		return smcTime;
	}
	public void setSmcTime(String smcTime) {
		this.smcTime = smcTime;
	}
	public String getSidTmp() {
		return sidTmp;
	}
	public void setSidTmp(String sidTmp) {
		this.sidTmp = sidTmp;
	}
	public String getSidTmp1() {
		return sidTmp1;
	}
	public void setSidTmp1(String sidTmp1) {
		this.sidTmp1 = sidTmp1;
	}
	
	

}
