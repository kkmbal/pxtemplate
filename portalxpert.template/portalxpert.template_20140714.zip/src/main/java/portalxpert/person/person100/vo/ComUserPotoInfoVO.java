package portalxpert.person.person100.vo;

public class ComUserPotoInfoVO {
	
	private String userId;
	private int potoSeq;
	private String filePath;
	private String fileName;
	private String fileExts;
	private String prvwPath;
	private String prvwName;
	private String prvwExts;
	private String delYn;
	private String regrId;
	private String regrName;
	private String regDttm;
	private String updrId;
	private String updrName;
	private String updDttm;
	private int photoCnt;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getPotoSeq() {
		return potoSeq;
	}
	public void setPotoSeq(int potoSeq) {
		this.potoSeq = potoSeq;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileExts() {
		return fileExts;
	}
	public void setFileExts(String fileExts) {
		this.fileExts = fileExts;
	}
	public String getPrvwPath() {
		return prvwPath;
	}
	public void setPrvwPath(String prvwPath) {
		this.prvwPath = prvwPath;
	}
	public String getPrvwName() {
		return prvwName;
	}
	public void setPrvwName(String prvwName) {
		this.prvwName = prvwName;
	}
	public String getPrvwExts() {
		return prvwExts;
	}
	public void setPrvwExts(String prvwExts) {
		this.prvwExts = prvwExts;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getRegrId() {
		return regrId;
	}
	public void setRegrId(String regrId) {
		this.regrId = regrId;
	}
	public String getRegrName() {
		return regrName;
	}
	public void setRegrName(String regrName) {
		this.regrName = regrName;
	}
	public String getRegDttm() {
		return regDttm;
	}
	public void setRegDttm(String regDttm) {
		this.regDttm = regDttm;
	}
	public String getUpdrId() {
		return updrId;
	}
	public void setUpdrId(String updrId) {
		this.updrId = updrId;
	}
	public String getUpdrName() {
		return updrName;
	}
	public void setUpdrName(String updrName) {
		this.updrName = updrName;
	}
	public String getUpdDttm() {
		return updDttm;
	}
	public void setUpdDttm(String updDttm) {
		this.updDttm = updDttm;
	}
	public int getPhotoCnt() {
		return photoCnt;
	}
	public void setPhotoCnt(int photoCnt) {
		this.photoCnt = photoCnt;
	}
	
	

}
