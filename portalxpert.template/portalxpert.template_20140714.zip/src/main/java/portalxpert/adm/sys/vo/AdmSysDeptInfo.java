package portalxpert.adm.sys.vo;

public class AdmSysDeptInfo {
	private String deptCode;
	private String deptName;
	private String parDeptCode;
	private String deptFname;
	
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getParDeptCode() {
		return parDeptCode;
	}
	public void setParDeptCode(String parDeptCode) {
		this.parDeptCode = parDeptCode;
	}
	public String getDeptFname() {
		return deptFname;
	}
	public void setDeptFname(String deptFname) {
		this.deptFname = deptFname;
	}
	
	
}
