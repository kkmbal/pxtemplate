package portalxpert.organization.vo;

public class BbsVO {
	private String userid;
	private String boardid;
	private String userMap;
	private String boardOperYn;
	
	
	public String getBoardOperYn() {
		return boardOperYn;
	}
	public void setBoardOperYn(String boardOperYn) {
		this.boardOperYn = boardOperYn;
	}
	public String getBoardid() {
		return boardid;
	}
	public void setBoardid(String boardid) {
		this.boardid = boardid;
	}
	public String getUserMap() {
		return userMap;
	}
	public void setUserMap(String userMap) {
		this.userMap = userMap;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getBoardId() {
		return boardid;
	}
	public void setBoardId(String boardid) {
		this.boardid = boardid;
	}

}
