package portalxpert.board.board100.vo;

public class BbsNotiSurveyAnswVO {
	
	private int surveyNo;
	private String answmanId;
	private String answmanName;
	private int answExmplNo;
	private String delYn;
	private String regrId;
	private String regrName;
	private String regDttm;
	private String updrId;
	private String updrName;
	private String updDttm;
	public int getSurveyNo() {
		return surveyNo;
	}
	public void setSurveyNo(int surveyNo) {
		this.surveyNo = surveyNo;
	}
	public String getAnswmanId() {
		return answmanId;
	}
	public void setAnswmanId(String answmanId) {
		this.answmanId = answmanId;
	}
	public String getAnswmanName() {
		return answmanName;
	}
	public void setAnswmanName(String answmanName) {
		this.answmanName = answmanName;
	}
	public int getAnswExmplNo() {
		return answExmplNo;
	}
	public void setAnswExmplNo(int answExmplNo) {
		this.answExmplNo = answExmplNo;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getRegrId() {
		return regrId;
	}
	public void setRegrId(String regrId) {
		this.regrId = regrId;
	}
	public String getRegrName() {
		return regrName;
	}
	public void setRegrName(String regrName) {
		this.regrName = regrName;
	}
	public String getRegDttm() {
		return regDttm;
	}
	public void setRegDttm(String regDttm) {
		this.regDttm = regDttm;
	}
	public String getUpdrId() {
		return updrId;
	}
	public void setUpdrId(String updrId) {
		this.updrId = updrId;
	}
	public String getUpdrName() {
		return updrName;
	}
	public void setUpdrName(String updrName) {
		this.updrName = updrName;
	}
	public String getUpdDttm() {
		return updDttm;
	}
	public void setUpdDttm(String updDttm) {
		this.updDttm = updDttm;
	}
	


}
